#!/bin/bash
    
age1=18
age2=`expr $age1 + 7`
    
echo "I am ${age1} years old"
echo "He is ${age2} years old"
