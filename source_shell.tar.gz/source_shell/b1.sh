#!/bin/bash
    
family=tiangtae
name=narathip
echo "I am ${name} ${family}"
