#!/bin/bash

echo $@
echo $#
echo $0
echo $1
