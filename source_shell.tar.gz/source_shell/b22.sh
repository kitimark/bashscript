#!/bin/bash

for file in  tmp1.txt tmp4.txt tmp6.txt
do
    echo "*** ${file} ***"
done
